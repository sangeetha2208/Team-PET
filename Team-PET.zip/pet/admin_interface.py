from fastapi import FastAPI, Request, Form, Depends
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime
import json

from database import get_db
from appointment_swapper import AppointmentSwapper
from notification_service import NotificationService
from emergency_prioritization_service import EmergencyPrioritizationService

# Initialize FastAPI app for admin interface
admin_app = FastAPI(title="HapiVet Admin Interface")

# Setup templates
templates = Jinja2Templates(directory="templates")

# Mount static files
admin_app.mount("/static", StaticFiles(directory="static"), name="static")

class AdminInterface:
    def __init__(self, db_session: Session):
        self.db = db_session
        self.appointment_swapper = AppointmentSwapper(db_session)
        self.notification_service = NotificationService()
        self.emergency_service = EmergencyPrioritizationService(db_session)

# Admin Dashboard
@admin_app.get("/", response_class=HTMLResponse)
async def admin_dashboard(request: Request, db: Session = Depends(get_db)):
    """Main admin dashboard"""
    try:
        admin_interface = AdminInterface(db)
        
        # Get system status
        system_status = admin_interface.emergency_service.get_system_status()
        
        # Get pending swaps
        pending_swaps = admin_interface.appointment_swapper.get_pending_swaps()
        
        # Get recent emergency cases
        emergency_cases = admin_interface.emergency_service.get_emergency_cases()
        recent_cases = emergency_cases[:5]  # Last 5 cases
        
        return templates.TemplateResponse("admin_dashboard.html", {
            "request": request,
            "system_status": system_status,
            "pending_swaps": pending_swaps,
            "recent_emergency_cases": recent_cases,
            "current_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        })
        
    except Exception as e:
        return templates.TemplateResponse("error.html", {
            "request": request,
            "error": str(e)
        })

# Pending Swaps Management
@admin_app.get("/swaps", response_class=HTMLResponse)
async def pending_swaps_page(request: Request, db: Session = Depends(get_db)):
    """Page showing all pending swap requests"""
    try:
        admin_interface = AdminInterface(db)
        pending_swaps = admin_interface.appointment_swapper.get_pending_swaps()
        
        return templates.TemplateResponse("pending_swaps.html", {
            "request": request,
            "pending_swaps": pending_swaps,
            "count": len(pending_swaps)
        })
        
    except Exception as e:
        return templates.TemplateResponse("error.html", {
            "request": request,
            "error": str(e)
        })

@admin_app.post("/swaps/{swap_id}/approve")
async def approve_swap(
    swap_id: int,
    admin_name: str = Form(...),
    reason: str = Form(""),
    db: Session = Depends(get_db)
):
    """Approve a swap request"""
    try:
        admin_interface = AdminInterface(db)
        
        result = admin_interface.appointment_swapper.approve_swap(swap_id, admin_name)
        
        if result["success"]:
            # Send approval notification
            admin_interface.notification_service.send_swap_approval_notification(
                {"swap_id": swap_id}, True, admin_name
            )
            
            return RedirectResponse(
                url="/swaps?message=Swap+approved+successfully",
                status_code=303
            )
        else:
            return RedirectResponse(
                url=f"/swaps?error={result['message']}",
                status_code=303
            )
            
    except Exception as e:
        return RedirectResponse(
            url=f"/swaps?error=Error+approving+swap:+{str(e)}",
            status_code=303
        )

@admin_app.post("/swaps/{swap_id}/reject")
async def reject_swap(
    swap_id: int,
    admin_name: str = Form(...),
    reason: str = Form(""),
    db: Session = Depends(get_db)
):
    """Reject a swap request"""
    try:
        admin_interface = AdminInterface(db)
        
        result = admin_interface.appointment_swapper.reject_swap(swap_id, admin_name, reason)
        
        if result["success"]:
            # Send rejection notification
            admin_interface.notification_service.send_swap_approval_notification(
                {"swap_id": swap_id}, False, admin_name
            )
            
            return RedirectResponse(
                url="/swaps?message=Swap+rejected+successfully",
                status_code=303
            )
        else:
            return RedirectResponse(
                url=f"/swaps?error={result['message']}",
                status_code=303
            )
            
    except Exception as e:
        return RedirectResponse(
            url=f"/swaps?error=Error+rejecting+swap:+{str(e)}",
            status_code=303
        )

# Emergency Cases Management
@admin_app.get("/emergency-cases", response_class=HTMLResponse)
async def emergency_cases_page(
    request: Request,
    status: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """Page showing all emergency cases"""
    try:
        admin_interface = AdminInterface(db)
        emergency_cases = admin_interface.emergency_service.get_emergency_cases(status)
        
        return templates.TemplateResponse("emergency_cases.html", {
            "request": request,
            "emergency_cases": emergency_cases,
            "count": len(emergency_cases),
            "filter_status": status
        })
        
    except Exception as e:
        return templates.TemplateResponse("error.html", {
            "request": request,
            "error": str(e)
        })

@admin_app.post("/emergency-cases/{case_id}/update-status")
async def update_emergency_case_status(
    case_id: int,
    new_status: str = Form(...),
    assigned_doctor_id: Optional[int] = Form(None),
    appointment_id: Optional[int] = Form(None),
    db: Session = Depends(get_db)
):
    """Update emergency case status"""
    try:
        admin_interface = AdminInterface(db)
        
        result = admin_interface.emergency_service.update_emergency_case_status(
            case_id, new_status, assigned_doctor_id, appointment_id
        )
        
        if result["success"]:
            return RedirectResponse(
                url="/emergency-cases?message=Status+updated+successfully",
                status_code=303
            )
        else:
            return RedirectResponse(
                url=f"/emergency-cases?error={result['message']}",
                status_code=303
            )
            
    except Exception as e:
        return RedirectResponse(
            url=f"/emergency-cases?error=Error+updating+status:+{str(e)}",
            status_code=303
        )

# System Status
@admin_app.get("/system-status", response_class=HTMLResponse)
async def system_status_page(request: Request, db: Session = Depends(get_db)):
    """System status and monitoring page"""
    try:
        admin_interface = AdminInterface(db)
        system_status = admin_interface.emergency_service.get_system_status()
        
        return templates.TemplateResponse("system_status.html", {
            "request": request,
            "system_status": system_status
        })
        
    except Exception as e:
        return templates.TemplateResponse("error.html", {
            "request": request,
            "error": str(e)
        })

# API endpoints for AJAX calls
@admin_app.get("/api/swaps/pending")
async def api_pending_swaps(db: Session = Depends(get_db)):
    """API endpoint for getting pending swaps"""
    try:
        admin_interface = AdminInterface(db)
        pending_swaps = admin_interface.appointment_swapper.get_pending_swaps()
        
        return {"pending_swaps": pending_swaps, "count": len(pending_swaps)}
        
    except Exception as e:
        return {"error": str(e), "pending_swaps": [], "count": 0}

@admin_app.get("/api/emergency-cases")
async def api_emergency_cases(
    status: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """API endpoint for getting emergency cases"""
    try:
        admin_interface = AdminInterface(db)
        emergency_cases = admin_interface.emergency_service.get_emergency_cases(status)
        
        return {"emergency_cases": emergency_cases, "count": len(emergency_cases)}
        
    except Exception as e:
        return {"error": str(e), "emergency_cases": [], "count": 0}

@admin_app.get("/api/system-status")
async def api_system_status(db: Session = Depends(get_db)):
    """API endpoint for getting system status"""
    try:
        admin_interface = AdminInterface(db)
        system_status = admin_interface.emergency_service.get_system_status()
        
        return system_status
        
    except Exception as e:
        return {"error": str(e), "system_status": "error"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(admin_app, host="0.0.0.0", port=8001)
