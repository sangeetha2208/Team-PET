import re
import openai
from typing import Dict, List, Tuple, Optional
from datetime import datetime
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import config

class AIEmergencyDetector:
    def __init__(self):
        self.emergency_keywords = config.settings.emergency_keywords
        self.severity_keywords = {
            "critical": ["unconscious", "not breathing", "severe bleeding", "trauma", "shock"],
            "urgent": ["difficulty breathing", "seizure", "poisoning", "severe pain", "vomiting blood"],
            "high": ["fever", "lethargy", "not eating", "limping", "discharge"]
        }
        
        # Initialize OpenAI client
        if config.settings.openai_api_key:
            openai.api_key = config.settings.openai_api_key
        
        # Initialize TF-IDF vectorizer for keyword matching
        self.vectorizer = TfidfVectorizer(stop_words='english')
        
    def detect_emergency(self, description: str, symptoms: str = "", patient_history: str = "") -> Dict:
        """
        Detect if a case is an emergency using AI analysis
        Returns: {
            "is_emergency": bool,
            "confidence": float,
            "severity_score": int,
            "reasoning": str,
            "recommended_priority": str
        }
        """
        try:
            # Combine all text for analysis
            full_text = f"{description} {symptoms} {patient_history}".lower()
            
            # Rule-based detection
            rule_based_result = self._rule_based_detection(full_text)
            
            # AI-based detection using OpenAI
            ai_result = self._ai_based_detection(description, symptoms, patient_history)
            
            # Combine results
            final_result = self._combine_results(rule_based_result, ai_result)
            
            return final_result
            
        except Exception as e:
            print(f"Error in emergency detection: {e}")
            return {
                "is_emergency": False,
                "confidence": 0.0,
                "severity_score": 1,
                "reasoning": f"Error in analysis: {str(e)}",
                "recommended_priority": "medium"
            }
    
    def _rule_based_detection(self, text: str) -> Dict:
        """Rule-based emergency detection using keyword matching"""
        emergency_score = 0
        matched_keywords = []
        
        # Check for emergency keywords
        for keyword in self.emergency_keywords:
            if keyword.lower() in text:
                emergency_score += 1
                matched_keywords.append(keyword)
        
        # Check severity levels
        severity_scores = {"critical": 10, "urgent": 7, "high": 4}
        max_severity = 0
        
        for level, keywords in self.severity_keywords.items():
            for keyword in keywords:
                if keyword.lower() in text:
                    severity_scores[level] = max(severity_scores[level], severity_scores[level])
                    max_severity = max(max_severity, severity_scores[level])
        
        is_emergency = emergency_score > 0 or max_severity >= 7
        confidence = min(emergency_score * 0.2 + max_severity * 0.1, 1.0)
        
        return {
            "is_emergency": is_emergency,
            "confidence": confidence,
            "severity_score": max_severity,
            "matched_keywords": matched_keywords,
            "reasoning": f"Matched {len(matched_keywords)} emergency keywords"
        }
    
    def _ai_based_detection(self, description: str, symptoms: str, history: str) -> Dict:
        """AI-based emergency detection using OpenAI"""
        try:
            if not config.settings.openai_api_key:
                return {"is_emergency": False, "confidence": 0.0, "reasoning": "OpenAI API not configured"}
            
            prompt = f"""
            Analyze this veterinary case for emergency indicators:
            
            Description: {description}
            Symptoms: {symptoms}
            Patient History: {history}
            
            Determine if this is an emergency case (1-10 scale) and provide reasoning.
            Consider: life-threatening conditions, severe pain, trauma, breathing issues, etc.
            
            Respond in JSON format:
            {{
                "emergency_score": <1-10>,
                "is_emergency": <true/false>,
                "reasoning": "<explanation>",
                "recommended_priority": "<low/medium/high/urgent/emergency>"
            }}
            """
            
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": prompt}],
                max_tokens=300,
                temperature=0.1
            )
            
            result = response.choices[0].message.content
            # Parse JSON response
            import json
            ai_result = json.loads(result)
            
            return {
                "is_emergency": ai_result.get("is_emergency", False),
                "confidence": ai_result.get("emergency_score", 0) / 10.0,
                "severity_score": ai_result.get("emergency_score", 1),
                "reasoning": ai_result.get("reasoning", ""),
                "recommended_priority": ai_result.get("recommended_priority", "medium")
            }
            
        except Exception as e:
            print(f"AI detection error: {e}")
            return {"is_emergency": False, "confidence": 0.0, "reasoning": f"AI analysis failed: {str(e)}"}
    
    def _combine_results(self, rule_result: Dict, ai_result: Dict) -> Dict:
        """Combine rule-based and AI-based results"""
        # Weight the results (70% AI, 30% rules)
        ai_weight = 0.7
        rule_weight = 0.3
        
        combined_confidence = (ai_result["confidence"] * ai_weight + 
                             rule_result["confidence"] * rule_weight)
        
        combined_emergency = (ai_result["is_emergency"] and ai_result["confidence"] > 0.5) or \
                           (rule_result["is_emergency"] and rule_result["confidence"] > 0.3)
        
        severity_score = max(ai_result.get("severity_score", 0), 
                           rule_result.get("severity_score", 0))
        
        reasoning = f"AI: {ai_result.get('reasoning', '')} | Rules: {rule_result.get('reasoning', '')}"
        
        return {
            "is_emergency": combined_emergency,
            "confidence": combined_confidence,
            "severity_score": severity_score,
            "reasoning": reasoning,
            "recommended_priority": ai_result.get("recommended_priority", "medium")
        }
    
    def get_emergency_priority(self, severity_score: int, confidence: float) -> str:
        """Determine priority level based on severity and confidence"""
        if severity_score >= 9 and confidence >= 0.8:
            return "emergency"
        elif severity_score >= 7 and confidence >= 0.6:
            return "urgent"
        elif severity_score >= 5 and confidence >= 0.4:
            return "high"
        elif severity_score >= 3:
            return "medium"
        else:
            return "low"

