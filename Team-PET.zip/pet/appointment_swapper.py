from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from models import Appointment, AppointmentSwap, SwapStatus, AppointmentStatus, AppointmentPriority
from doctor_availability_manager import DoctorAvailabilityManager
import config

class AppointmentSwapper:
    def __init__(self, db_session: Session):
        self.db = db_session
        self.availability_manager = DoctorAvailabilityManager(db_session)
        
    def create_emergency_appointment(self, 
                                   patient_id: int,
                                   emergency_description: str,
                                   symptoms: str = "",
                                   patient_history: str = "",
                                   preferred_doctor_id: int = None) -> Dict:
        """
        Create an emergency appointment and handle swapping if necessary
        Returns: {
            "success": bool,
            "appointment_id": int,
            "swap_required": bool,
            "swap_request_id": int,
            "message": str
        }
        """
        try:
            # Find available doctors for immediate appointment
            available_doctors = self.availability_manager.find_available_doctors(
                start_time=datetime.now(),
                duration=30,
                patient_preferred_doctor_id=preferred_doctor_id
            )
            
            if not available_doctors:
                # No immediate availability, need to swap
                return self._handle_swap_required(patient_id, emergency_description, preferred_doctor_id)
            
            # Create emergency appointment with available doctor
            appointment = self._create_appointment(
                patient_id=patient_id,
                doctor_id=available_doctors[0]["doctor_id"],
                scheduled_time=datetime.now(),
                reason=emergency_description,
                priority=AppointmentPriority.EMERGENCY,
                is_emergency=True
            )
            
            return {
                "success": True,
                "appointment_id": appointment.id,
                "swap_required": False,
                "swap_request_id": None,
                "message": f"Emergency appointment created with Dr. {available_doctors[0]['name']}"
            }
            
        except Exception as e:
            print(f"Error creating emergency appointment: {e}")
            return {
                "success": False,
                "appointment_id": None,
                "swap_required": False,
                "swap_request_id": None,
                "message": f"Error: {str(e)}"
            }
    
    def _handle_swap_required(self, 
                            patient_id: int, 
                            emergency_description: str,
                            preferred_doctor_id: int = None) -> Dict:
        """Handle case where swapping is required for emergency appointment"""
        try:
            # Find the best doctor for emergency (preferred or most suitable)
            target_doctor_id = preferred_doctor_id
            if not target_doctor_id:
                emergency_doctors = self.availability_manager.get_emergency_doctors()
                if emergency_doctors:
                    target_doctor_id = emergency_doctors[0]["doctor_id"]
                else:
                    return {
                        "success": False,
                        "appointment_id": None,
                        "swap_required": True,
                        "swap_request_id": None,
                        "message": "No emergency doctors available"
                    }
            
            # Find appointments to potentially swap
            swap_candidates = self._find_swap_candidates(target_doctor_id)
            
            if not swap_candidates:
                return {
                    "success": False,
                    "appointment_id": None,
                    "swap_required": True,
                    "swap_request_id": None,
                    "message": "No swap candidates found"
                }
            
            # Create swap request
            swap_request = self._create_swap_request(
                patient_id=patient_id,
                target_doctor_id=target_doctor_id,
                emergency_description=emergency_description,
                swap_candidates=swap_candidates
            )
            
            return {
                "success": False,
                "appointment_id": None,
                "swap_required": True,
                "swap_request_id": swap_request.id,
                "message": f"Swap request created. {len(swap_candidates)} candidates found."
            }
            
        except Exception as e:
            print(f"Error handling swap requirement: {e}")
            return {
                "success": False,
                "appointment_id": None,
                "swap_required": True,
                "swap_request_id": None,
                "message": f"Error: {str(e)}"
            }
    
    def _find_swap_candidates(self, doctor_id: int) -> List[Dict]:
        """Find appointments that could be swapped to make room for emergency"""
        try:
            # Get today's appointments for the doctor
            today = datetime.now().date()
            start_of_day = datetime.combine(today, datetime.min.time())
            end_of_day = start_of_day + timedelta(days=1)
            
            appointments = self.db.query(Appointment).filter(
                Appointment.doctor_id == doctor_id,
                Appointment.scheduled_time >= start_of_day,
                Appointment.scheduled_time < end_of_day,
                Appointment.status.in_([AppointmentStatus.SCHEDULED, AppointmentStatus.CONFIRMED]),
                Appointment.priority != AppointmentPriority.EMERGENCY
            ).order_by(Appointment.scheduled_time).all()
            
            candidates = []
            for appointment in appointments:
                # Check if this appointment can be moved
                next_available_slot = self.availability_manager.find_next_available_slot(
                    doctor_id=appointment.doctor_id,
                    preferred_start=appointment.scheduled_time + timedelta(hours=1),
                    duration=appointment.duration
                )
                
                if next_available_slot:
                    candidates.append({
                        "appointment_id": appointment.id,
                        "patient_name": appointment.patient.name if appointment.patient else "Unknown",
                        "current_time": appointment.scheduled_time,
                        "new_time": next_available_slot,
                        "priority": appointment.priority.value,
                        "reason": appointment.reason
                    })
            
            return candidates
            
        except Exception as e:
            print(f"Error finding swap candidates: {e}")
            return []
    
    def _create_swap_request(self, 
                           patient_id: int,
                           target_doctor_id: int,
                           emergency_description: str,
                           swap_candidates: List[Dict]) -> AppointmentSwap:
        """Create a swap request for admin approval"""
        try:
            # Create the emergency appointment (pending)
            emergency_appointment = self._create_appointment(
                patient_id=patient_id,
                doctor_id=target_doctor_id,
                scheduled_time=datetime.now(),
                reason=emergency_description,
                priority=AppointmentPriority.EMERGENCY,
                is_emergency=True,
                status=AppointmentStatus.SCHEDULED
            )
            
            # Create swap request
            swap_request = AppointmentSwap(
                original_appointment_id=swap_candidates[0]["appointment_id"] if swap_candidates else None,
                new_appointment_id=emergency_appointment.id,
                reason=f"Emergency case: {emergency_description}",
                status=SwapStatus.PENDING,
                requested_by="Emergency System"
            )
            
            self.db.add(swap_request)
            self.db.commit()
            
            return swap_request
            
        except Exception as e:
            print(f"Error creating swap request: {e}")
            raise e
    
    def _create_appointment(self, 
                           patient_id: int,
                           doctor_id: int,
                           scheduled_time: datetime,
                           reason: str,
                           priority: AppointmentPriority,
                           is_emergency: bool = False,
                           status: AppointmentStatus = AppointmentStatus.SCHEDULED) -> Appointment:
        """Create a new appointment"""
        try:
            appointment = Appointment(
                patient_id=patient_id,
                doctor_id=doctor_id,
                scheduled_time=scheduled_time,
                duration=30,
                reason=reason,
                priority=priority,
                is_emergency=is_emergency,
                status=status
            )
            
            self.db.add(appointment)
            self.db.commit()
            
            return appointment
            
        except Exception as e:
            print(f"Error creating appointment: {e}")
            raise e
    
    def approve_swap(self, swap_request_id: int, approved_by: str) -> Dict:
        """Approve a swap request"""
        try:
            swap_request = self.db.query(AppointmentSwap).filter(
                AppointmentSwap.id == swap_request_id
            ).first()
            
            if not swap_request:
                return {"success": False, "message": "Swap request not found"}
            
            if swap_request.status != SwapStatus.PENDING:
                return {"success": False, "message": "Swap request already processed"}
            
            # Get the appointments
            original_appointment = self.db.query(Appointment).filter(
                Appointment.id == swap_request.original_appointment_id
            ).first()
            
            new_appointment = self.db.query(Appointment).filter(
                Appointment.id == swap_request.new_appointment_id
            ).first()
            
            if not original_appointment or not new_appointment:
                return {"success": False, "message": "Appointments not found"}
            
            # Find new slot for original appointment
            next_slot = self.availability_manager.find_next_available_slot(
                doctor_id=original_appointment.doctor_id,
                preferred_start=original_appointment.scheduled_time + timedelta(hours=1),
                duration=original_appointment.duration
            )
            
            if not next_slot:
                return {"success": False, "message": "No available slot for original appointment"}
            
            # Update appointments
            original_appointment.scheduled_time = next_slot
            original_appointment.status = AppointmentStatus.SCHEDULED
            
            new_appointment.status = AppointmentStatus.CONFIRMED
            
            # Update swap request
            swap_request.status = SwapStatus.APPROVED
            swap_request.approved_by = approved_by
            
            self.db.commit()
            
            return {
                "success": True,
                "message": f"Swap approved. Original appointment moved to {next_slot}",
                "original_appointment_new_time": next_slot,
                "emergency_appointment_time": new_appointment.scheduled_time
            }
            
        except Exception as e:
            print(f"Error approving swap: {e}")
            return {"success": False, "message": f"Error: {str(e)}"}
    
    def reject_swap(self, swap_request_id: int, rejected_by: str, reason: str = "") -> Dict:
        """Reject a swap request"""
        try:
            swap_request = self.db.query(AppointmentSwap).filter(
                AppointmentSwap.id == swap_request_id
            ).first()
            
            if not swap_request:
                return {"success": False, "message": "Swap request not found"}
            
            # Update swap request
            swap_request.status = SwapStatus.REJECTED
            swap_request.approved_by = rejected_by
            swap_request.reason = f"Rejected: {reason}"
            
            # Cancel the emergency appointment
            emergency_appointment = self.db.query(Appointment).filter(
                Appointment.id == swap_request.new_appointment_id
            ).first()
            
            if emergency_appointment:
                emergency_appointment.status = AppointmentStatus.CANCELLED
            
            self.db.commit()
            
            return {
                "success": True,
                "message": "Swap request rejected and emergency appointment cancelled"
            }
            
        except Exception as e:
            print(f"Error rejecting swap: {e}")
            return {"success": False, "message": f"Error: {str(e)}"}
    
    def get_pending_swaps(self) -> List[Dict]:
        """Get all pending swap requests"""
        try:
            pending_swaps = self.db.query(AppointmentSwap).filter(
                AppointmentSwap.status == SwapStatus.PENDING
            ).all()
            
            swap_details = []
            for swap in pending_swaps:
                original_appointment = self.db.query(Appointment).filter(
                    Appointment.id == swap.original_appointment_id
                ).first()
                
                new_appointment = self.db.query(Appointment).filter(
                    Appointment.id == swap.new_appointment_id
                ).first()
                
                swap_details.append({
                    "swap_id": swap.id,
                    "original_appointment": {
                        "id": original_appointment.id if original_appointment else None,
                        "patient_name": original_appointment.patient.name if original_appointment and original_appointment.patient else "Unknown",
                        "scheduled_time": original_appointment.scheduled_time if original_appointment else None,
                        "reason": original_appointment.reason if original_appointment else None
                    },
                    "emergency_appointment": {
                        "id": new_appointment.id if new_appointment else None,
                        "patient_name": new_appointment.patient.name if new_appointment and new_appointment.patient else "Unknown",
                        "scheduled_time": new_appointment.scheduled_time if new_appointment else None,
                        "reason": new_appointment.reason if new_appointment else None
                    },
                    "reason": swap.reason,
                    "requested_by": swap.requested_by,
                    "created_at": swap.created_at
                })
            
            return swap_details
            
        except Exception as e:
            print(f"Error getting pending swaps: {e}")
            return []

