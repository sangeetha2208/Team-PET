import os
from typing import Optional
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    # Database
    database_url: str = "postgresql://user:password@localhost/hapivet"
    
    # API Keys
    openai_api_key: Optional[str] = None
    
    # Emergency System
    emergency_keywords: list = [
        "emergency", "urgent", "critical", "life-threatening", 
        "severe", "acute", "trauma", "bleeding", "unconscious",
        "breathing problems", "seizure", "poisoning", "accident"
    ]
    
    # Doctor Specializations
    doctor_specializations: dict = {
        "emergency": ["Dr. Sarah Wilson", "Dr. Mike Johnson"],
        "surgery": ["Dr. Sarah Wilson", "Dr. Lisa Chen"],
        "cardiology": ["Dr. Mike Johnson"],
        "dermatology": ["Dr. Lisa Chen"],
        "general": ["Dr. Sarah Wilson", "Dr. Mike Johnson", "Dr. Lisa Chen"]
    }
    
    # Notification Settings
    admin_email: str = "admin@hapivet.com"
    notification_webhook: Optional[str] = None
    
    # System Settings
    max_appointment_duration: int = 30  # minutes
    buffer_time: int = 15  # minutes between appointments
    
    class Config:
        env_file = ".env"

settings = Settings()

