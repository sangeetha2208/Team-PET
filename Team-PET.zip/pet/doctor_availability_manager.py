from typing import List, Dict, Optional, Tuple
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from models import Doctor, DoctorShift, Appointment, AppointmentStatus
import config

class DoctorAvailabilityManager:
    def __init__(self, db_session: Session):
        self.db = db_session
        
    def find_available_doctors(self, 
                             start_time: datetime, 
                             duration: int = 30,
                             specialization: str = None,
                             patient_preferred_doctor_id: int = None) -> List[Dict]:
        """
        Find available doctors for a given time slot
        Returns list of available doctors with their details
        """
        try:
            end_time = start_time + timedelta(minutes=duration)
            
            # Get all doctors
            query = self.db.query(Doctor).filter(Doctor.is_available == True)
            
            # Filter by specialization if specified
            if specialization:
                query = query.filter(Doctor.specialization == specialization)
            
            doctors = query.all()
            available_doctors = []
            
            for doctor in doctors:
                # Check if doctor has shift during this time
                has_shift = self._check_doctor_shift(doctor.id, start_time, end_time)
                
                if not has_shift:
                    continue
                
                # Check for existing appointments
                has_conflict = self._check_appointment_conflicts(doctor.id, start_time, end_time)
                
                if not has_conflict:
                    # Calculate priority score
                    priority_score = self._calculate_priority_score(
                        doctor, patient_preferred_doctor_id, specialization
                    )
                    
                    available_doctors.append({
                        "doctor_id": doctor.id,
                        "name": doctor.name,
                        "specialization": doctor.specialization,
                        "email": doctor.email,
                        "phone": doctor.phone,
                        "priority_score": priority_score,
                        "is_preferred": doctor.id == patient_preferred_doctor_id
                    })
            
            # Sort by priority score (highest first)
            available_doctors.sort(key=lambda x: x["priority_score"], reverse=True)
            
            return available_doctors
            
        except Exception as e:
            print(f"Error finding available doctors: {e}")
            return []
    
    def find_next_available_slot(self, 
                               doctor_id: int, 
                               preferred_start: datetime = None,
                               duration: int = 30) -> Optional[datetime]:
        """
        Find the next available slot for a specific doctor
        """
        try:
            if not preferred_start:
                preferred_start = datetime.now()
            
            # Look for slots in the next 7 days
            end_search = preferred_start + timedelta(days=7)
            current_time = preferred_start
            
            while current_time < end_search:
                # Check if doctor has shift
                if self._check_doctor_shift(doctor_id, current_time, current_time + timedelta(minutes=duration)):
                    # Check for conflicts
                    if not self._check_appointment_conflicts(doctor_id, current_time, current_time + timedelta(minutes=duration)):
                        return current_time
                
                # Move to next 30-minute slot
                current_time += timedelta(minutes=30)
            
            return None
            
        except Exception as e:
            print(f"Error finding next available slot: {e}")
            return None
    
    def get_doctor_schedule(self, doctor_id: int, date: datetime) -> List[Dict]:
        """
        Get doctor's schedule for a specific date
        """
        try:
            start_of_day = date.replace(hour=0, minute=0, second=0, microsecond=0)
            end_of_day = start_of_day + timedelta(days=1)
            
            # Get appointments
            appointments = self.db.query(Appointment).filter(
                Appointment.doctor_id == doctor_id,
                Appointment.scheduled_time >= start_of_day,
                Appointment.scheduled_time < end_of_day,
                Appointment.status.in_([AppointmentStatus.SCHEDULED, AppointmentStatus.CONFIRMED, AppointmentStatus.IN_PROGRESS])
            ).order_by(Appointment.scheduled_time).all()
            
            schedule = []
            for appointment in appointments:
                schedule.append({
                    "appointment_id": appointment.id,
                    "patient_name": appointment.patient.name if appointment.patient else "Unknown",
                    "start_time": appointment.scheduled_time,
                    "end_time": appointment.scheduled_time + timedelta(minutes=appointment.duration),
                    "status": appointment.status.value,
                    "priority": appointment.priority.value,
                    "reason": appointment.reason
                })
            
            return schedule
            
        except Exception as e:
            print(f"Error getting doctor schedule: {e}")
            return []
    
    def _check_doctor_shift(self, doctor_id: int, start_time: datetime, end_time: datetime) -> bool:
        """Check if doctor has a shift during the specified time"""
        try:
            shift = self.db.query(DoctorShift).filter(
                DoctorShift.doctor_id == doctor_id,
                DoctorShift.start_time <= start_time,
                DoctorShift.end_time >= end_time,
                DoctorShift.is_available == True
            ).first()
            
            return shift is not None
            
        except Exception as e:
            print(f"Error checking doctor shift: {e}")
            return False
    
    def _check_appointment_conflicts(self, doctor_id: int, start_time: datetime, end_time: datetime) -> bool:
        """Check if there are appointment conflicts during the specified time"""
        try:
            conflict = self.db.query(Appointment).filter(
                Appointment.doctor_id == doctor_id,
                Appointment.scheduled_time < end_time,
                Appointment.scheduled_time + timedelta(minutes=Appointment.duration) > start_time,
                Appointment.status.in_([AppointmentStatus.SCHEDULED, AppointmentStatus.CONFIRMED, AppointmentStatus.IN_PROGRESS])
            ).first()
            
            return conflict is not None
            
        except Exception as e:
            print(f"Error checking appointment conflicts: {e}")
            return True  # Assume conflict if error
    
    def _calculate_priority_score(self, 
                                doctor: Doctor, 
                                patient_preferred_doctor_id: int = None,
                                required_specialization: str = None) -> float:
        """Calculate priority score for doctor selection"""
        score = 0.0
        
        # Base score
        score += 1.0
        
        # Preferred doctor bonus
        if patient_preferred_doctor_id and doctor.id == patient_preferred_doctor_id:
            score += 5.0
        
        # Specialization match bonus
        if required_specialization and doctor.specialization == required_specialization:
            score += 3.0
        
        # Emergency specialization bonus
        if doctor.specialization in ["emergency", "surgery", "critical care"]:
            score += 2.0
        
        return score
    
    def get_emergency_doctors(self) -> List[Dict]:
        """Get doctors available for emergency cases"""
        try:
            emergency_doctors = self.db.query(Doctor).filter(
                Doctor.is_available == True,
                Doctor.specialization.in_(["emergency", "surgery", "critical care", "general"])
            ).all()
            
            return [{
                "doctor_id": doctor.id,
                "name": doctor.name,
                "specialization": doctor.specialization,
                "email": doctor.email,
                "phone": doctor.phone
            } for doctor in emergency_doctors]
            
        except Exception as e:
            print(f"Error getting emergency doctors: {e}")
            return []

