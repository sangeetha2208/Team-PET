from typing import Dict, List, Optional
from datetime import datetime
from sqlalchemy.orm import Session
from models import Patient, Doctor, Appointment, EmergencyCase, AppointmentStatus, AppointmentPriority
from ai_emergency_detector import AIEmergencyDetector
from doctor_availability_manager import DoctorAvailabilityManager
from appointment_swapper import AppointmentSwapper
from notification_service import NotificationService
import config

class EmergencyPrioritizationService:
    def __init__(self, db_session: Session):
        self.db = db_session
        self.ai_detector = AIEmergencyDetector()
        self.availability_manager = DoctorAvailabilityManager(db_session)
        self.appointment_swapper = AppointmentSwapper(db_session)
        self.notification_service = NotificationService()
        
    def process_emergency_case(self, 
                              patient_id: int,
                              description: str,
                              symptoms: str = "",
                              patient_history: str = "",
                              preferred_doctor_id: int = None) -> Dict:
        """
        Main method to process an emergency case
        Returns comprehensive result with appointment details and notifications
        """
        try:
            # Step 1: AI Emergency Detection
            print("Step 1: Analyzing emergency case...")
            ai_analysis = self.ai_detector.detect_emergency(description, symptoms, patient_history)
            
            if not ai_analysis["is_emergency"]:
                return {
                    "success": False,
                    "is_emergency": False,
                    "message": "Case does not qualify as emergency based on AI analysis",
                    "ai_analysis": ai_analysis
                }
            
            # Step 2: Create Emergency Case Record
            print("Step 2: Creating emergency case record...")
            emergency_case = self._create_emergency_case_record(
                patient_id, description, ai_analysis, symptoms, patient_history
            )
            
            # Step 3: Find Available Doctor
            print("Step 3: Finding available doctor...")
            available_doctors = self.availability_manager.find_available_doctors(
                start_time=datetime.now(),
                duration=30,
                patient_preferred_doctor_id=preferred_doctor_id
            )
            
            # Step 4: Create Emergency Appointment
            print("Step 4: Creating emergency appointment...")
            appointment_result = self.appointment_swapper.create_emergency_appointment(
                patient_id=patient_id,
                emergency_description=description,
                symptoms=symptoms,
                patient_history=patient_history,
                preferred_doctor_id=preferred_doctor_id
            )
            
            # Step 5: Send Notifications
            print("Step 5: Sending notifications...")
            if appointment_result["success"]:
                self._send_emergency_notifications(emergency_case, appointment_result)
            elif appointment_result["swap_required"]:
                self._send_swap_request_notifications(appointment_result)
            
            return {
                "success": appointment_result["success"],
                "is_emergency": True,
                "emergency_case_id": emergency_case.id,
                "appointment_id": appointment_result.get("appointment_id"),
                "swap_required": appointment_result.get("swap_required", False),
                "swap_request_id": appointment_result.get("swap_request_id"),
                "ai_analysis": ai_analysis,
                "available_doctors": available_doctors,
                "message": appointment_result.get("message"),
                "next_steps": self._get_next_steps(appointment_result)
            }
            
        except Exception as e:
            print(f"Error processing emergency case: {e}")
            return {
                "success": False,
                "is_emergency": False,
                "message": f"System error: {str(e)}",
                "error": str(e)
            }
    
    def _create_emergency_case_record(self, 
                                    patient_id: int,
                                    description: str,
                                    ai_analysis: Dict,
                                    symptoms: str,
                                    patient_history: str) -> EmergencyCase:
        """Create emergency case record in database"""
        try:
            emergency_case = EmergencyCase(
                patient_id=patient_id,
                description=description,
                severity_score=ai_analysis.get("severity_score", 1),
                ai_confidence=ai_analysis.get("confidence", 0.0),
                status="pending"
            )
            
            self.db.add(emergency_case)
            self.db.commit()
            
            return emergency_case
            
        except Exception as e:
            print(f"Error creating emergency case record: {e}")
            raise e
    
    def _send_emergency_notifications(self, emergency_case: EmergencyCase, appointment_result: Dict):
        """Send notifications for successful emergency appointment"""
        try:
            # Get patient and doctor details
            patient = self.db.query(Patient).filter(Patient.id == emergency_case.patient_id).first()
            appointment = self.db.query(Appointment).filter(Appointment.id == appointment_result["appointment_id"]).first()
            doctor = self.db.query(Doctor).filter(Doctor.id == appointment.doctor_id).first()
            
            # Prepare notification data
            emergency_data = {
                "patient_name": patient.name if patient else "Unknown",
                "description": emergency_case.description,
                "severity_score": emergency_case.severity_score,
                "ai_confidence": emergency_case.ai_confidence
            }
            
            doctor_data = {
                "name": doctor.name if doctor else "Unknown",
                "email": doctor.email if doctor else None,
                "phone": doctor.phone if doctor else None
            }
            
            appointment_data = {
                "scheduled_time": appointment.scheduled_time,
                "reason": appointment.reason
            }
            
            # Send notifications
            self.notification_service.send_emergency_notification(
                emergency_data, doctor_data, appointment_data
            )
            
        except Exception as e:
            print(f"Error sending emergency notifications: {e}")
    
    def _send_swap_request_notifications(self, appointment_result: Dict):
        """Send notifications for swap request"""
        try:
            if appointment_result.get("swap_request_id"):
                # Get swap request details
                swap_request = self.appointment_swapper.get_pending_swaps()
                if swap_request:
                    self.notification_service.send_swap_request_notification(swap_request[0])
                    
        except Exception as e:
            print(f"Error sending swap request notifications: {e}")
    
    def _get_next_steps(self, appointment_result: Dict) -> List[str]:
        """Get next steps based on appointment result"""
        next_steps = []
        
        if appointment_result["success"]:
            next_steps.extend([
                "Emergency appointment created successfully",
                "Doctor has been notified",
                "Patient should be prepared for immediate consultation"
            ])
        elif appointment_result.get("swap_required"):
            next_steps.extend([
                "Swap request created and sent to admin",
                "Admin approval required",
                "Original appointment will be moved to next available slot",
                "Emergency appointment will be confirmed upon approval"
            ])
        else:
            next_steps.extend([
                "No immediate solution found",
                "Manual intervention may be required",
                "Contact admin for assistance"
            ])
        
        return next_steps
    
    def get_emergency_cases(self, status: str = None) -> List[Dict]:
        """Get emergency cases with optional status filter"""
        try:
            query = self.db.query(EmergencyCase)
            
            if status:
                query = query.filter(EmergencyCase.status == status)
            
            emergency_cases = query.order_by(EmergencyCase.created_at.desc()).all()
            
            cases_data = []
            for case in emergency_cases:
                patient = self.db.query(Patient).filter(Patient.id == case.patient_id).first()
                doctor = self.db.query(Doctor).filter(Doctor.id == case.assigned_doctor_id).first()
                appointment = self.db.query(Appointment).filter(Appointment.id == case.appointment_id).first()
                
                cases_data.append({
                    "emergency_case_id": case.id,
                    "patient_name": patient.name if patient else "Unknown",
                    "description": case.description,
                    "severity_score": case.severity_score,
                    "ai_confidence": case.ai_confidence,
                    "assigned_doctor": doctor.name if doctor else None,
                    "appointment_time": appointment.scheduled_time if appointment else None,
                    "status": case.status,
                    "created_at": case.created_at
                })
            
            return cases_data
            
        except Exception as e:
            print(f"Error getting emergency cases: {e}")
            return []
    
    def update_emergency_case_status(self, 
                                   emergency_case_id: int, 
                                   status: str,
                                   assigned_doctor_id: int = None,
                                   appointment_id: int = None) -> Dict:
        """Update emergency case status"""
        try:
            emergency_case = self.db.query(EmergencyCase).filter(
                EmergencyCase.id == emergency_case_id
            ).first()
            
            if not emergency_case:
                return {"success": False, "message": "Emergency case not found"}
            
            emergency_case.status = status
            
            if assigned_doctor_id:
                emergency_case.assigned_doctor_id = assigned_doctor_id
            
            if appointment_id:
                emergency_case.appointment_id = appointment_id
            
            self.db.commit()
            
            return {"success": True, "message": "Emergency case status updated"}
            
        except Exception as e:
            print(f"Error updating emergency case status: {e}")
            return {"success": False, "message": f"Error: {str(e)}"}
    
    def get_system_status(self) -> Dict:
        """Get overall system status"""
        try:
            # Count emergency cases by status
            emergency_cases = self.db.query(EmergencyCase).all()
            cases_by_status = {}
            for case in emergency_cases:
                status = case.status
                cases_by_status[status] = cases_by_status.get(status, 0) + 1
            
            # Count pending swaps
            pending_swaps = self.appointment_swapper.get_pending_swaps()
            
            # Get available doctors
            available_doctors = self.availability_manager.get_emergency_doctors()
            
            return {
                "emergency_cases": cases_by_status,
                "pending_swaps": len(pending_swaps),
                "available_emergency_doctors": len(available_doctors),
                "system_status": "operational",
                "last_updated": datetime.now().isoformat()
            }
            
        except Exception as e:
            print(f"Error getting system status: {e}")
            return {
                "system_status": "error",
                "error": str(e),
                "last_updated": datetime.now().isoformat()
            }

