from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime
import uvicorn

# Import our modules
from models import Base, Patient, Doctor, Appointment, EmergencyCase
from emergency_prioritization_service import EmergencyPrioritizationService
from appointment_swapper import AppointmentSwapper
from notification_service import NotificationService
from database import get_db, engine

# Create database tables
Base.metadata.create_all(bind=engine)

# Initialize FastAPI app
app = FastAPI(
    title="HapiVet Emergency Prioritization System",
    description="AI-powered emergency case prioritization and appointment management",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Pydantic models for request/response
from pydantic import BaseModel

class EmergencyCaseRequest(BaseModel):
    patient_id: int
    description: str
    symptoms: Optional[str] = ""
    patient_history: Optional[str] = ""
    preferred_doctor_id: Optional[int] = None

class SwapApprovalRequest(BaseModel):
    swap_request_id: int
    approved: bool
    admin_name: str
    reason: Optional[str] = ""

class PatientCreate(BaseModel):
    name: str
    species: Optional[str] = None
    breed: Optional[str] = None
    age: Optional[int] = None
    owner_name: str
    owner_phone: str
    owner_email: Optional[str] = None
    preferred_doctor_id: Optional[int] = None
    medical_history: Optional[str] = None

class DoctorCreate(BaseModel):
    name: str
    specialization: str
    email: str
    phone: str

# Initialize services
def get_emergency_service(db: Session = Depends(get_db)):
    return EmergencyPrioritizationService(db)

def get_appointment_swapper(db: Session = Depends(get_db)):
    return AppointmentSwapper(db)

def get_notification_service():
    return NotificationService()

# API Endpoints

@app.get("/")
async def root():
    return {
        "message": "HapiVet Emergency Prioritization System",
        "version": "1.0.0",
        "status": "operational"
    }

@app.get("/health")
async def health_check():
    return {"status": "healthy", "timestamp": datetime.now().isoformat()}

# Emergency Case Endpoints

@app.post("/emergency/process")
async def process_emergency_case(
    request: EmergencyCaseRequest,
    emergency_service: EmergencyPrioritizationService = Depends(get_emergency_service)
):
    """
    Process an emergency case with AI analysis and automatic appointment booking
    """
    try:
        result = emergency_service.process_emergency_case(
            patient_id=request.patient_id,
            description=request.description,
            symptoms=request.symptoms,
            patient_history=request.patient_history,
            preferred_doctor_id=request.preferred_doctor_id
        )
        
        return result
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error processing emergency case: {str(e)}"
        )

@app.get("/emergency/cases")
async def get_emergency_cases(
    status: Optional[str] = None,
    emergency_service: EmergencyPrioritizationService = Depends(get_emergency_service)
):
    """
    Get all emergency cases with optional status filter
    """
    try:
        cases = emergency_service.get_emergency_cases(status)
        return {"emergency_cases": cases, "count": len(cases)}
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error retrieving emergency cases: {str(e)}"
        )

@app.put("/emergency/cases/{case_id}/status")
async def update_emergency_case_status(
    case_id: int,
    status: str,
    assigned_doctor_id: Optional[int] = None,
    appointment_id: Optional[int] = None,
    emergency_service: EmergencyPrioritizationService = Depends(get_emergency_service)
):
    """
    Update emergency case status
    """
    try:
        result = emergency_service.update_emergency_case_status(
            case_id, status, assigned_doctor_id, appointment_id
        )
        return result
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error updating emergency case status: {str(e)}"
        )

# Appointment Swap Endpoints

@app.get("/swaps/pending")
async def get_pending_swaps(
    appointment_swapper: AppointmentSwapper = Depends(get_appointment_swapper)
):
    """
    Get all pending swap requests requiring admin approval
    """
    try:
        pending_swaps = appointment_swapper.get_pending_swaps()
        return {"pending_swaps": pending_swaps, "count": len(pending_swaps)}
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error retrieving pending swaps: {str(e)}"
        )

@app.post("/swaps/approve")
async def approve_swap_request(
    request: SwapApprovalRequest,
    appointment_swapper: AppointmentSwapper = Depends(get_appointment_swapper)
):
    """
    Approve or reject a swap request
    """
    try:
        if request.approved:
            result = appointment_swapper.approve_swap(
                request.swap_request_id, request.admin_name
            )
        else:
            result = appointment_swapper.reject_swap(
                request.swap_request_id, request.admin_name, request.reason
            )
        
        return result
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error processing swap request: {str(e)}"
        )

# Patient Management Endpoints

@app.post("/patients")
async def create_patient(
    patient_data: PatientCreate,
    db: Session = Depends(get_db)
):
    """
    Create a new patient
    """
    try:
        patient = Patient(
            name=patient_data.name,
            species=patient_data.species,
            breed=patient_data.breed,
            age=patient_data.age,
            owner_name=patient_data.owner_name,
            owner_phone=patient_data.owner_phone,
            owner_email=patient_data.owner_email,
            preferred_doctor_id=patient_data.preferred_doctor_id,
            medical_history=patient_data.medical_history
        )
        
        db.add(patient)
        db.commit()
        db.refresh(patient)
        
        return {
            "success": True,
            "patient_id": patient.id,
            "message": "Patient created successfully"
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error creating patient: {str(e)}"
        )

@app.get("/patients/{patient_id}")
async def get_patient(patient_id: int, db: Session = Depends(get_db)):
    """
    Get patient details
    """
    try:
        patient = db.query(Patient).filter(Patient.id == patient_id).first()
        
        if not patient:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Patient not found"
            )
        
        return {
            "patient_id": patient.id,
            "name": patient.name,
            "species": patient.species,
            "breed": patient.breed,
            "age": patient.age,
            "owner_name": patient.owner_name,
            "owner_phone": patient.owner_phone,
            "owner_email": patient.owner_email,
            "preferred_doctor_id": patient.preferred_doctor_id,
            "medical_history": patient.medical_history,
            "created_at": patient.created_at
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error retrieving patient: {str(e)}"
        )

# Doctor Management Endpoints

@app.post("/doctors")
async def create_doctor(
    doctor_data: DoctorCreate,
    db: Session = Depends(get_db)
):
    """
    Create a new doctor
    """
    try:
        doctor = Doctor(
            name=doctor_data.name,
            specialization=doctor_data.specialization,
            email=doctor_data.email,
            phone=doctor_data.phone
        )
        
        db.add(doctor)
        db.commit()
        db.refresh(doctor)
        
        return {
            "success": True,
            "doctor_id": doctor.id,
            "message": "Doctor created successfully"
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error creating doctor: {str(e)}"
        )

@app.get("/doctors")
async def get_doctors(db: Session = Depends(get_db)):
    """
    Get all doctors
    """
    try:
        doctors = db.query(Doctor).all()
        
        return {
            "doctors": [
                {
                    "doctor_id": doctor.id,
                    "name": doctor.name,
                    "specialization": doctor.specialization,
                    "email": doctor.email,
                    "phone": doctor.phone,
                    "is_available": doctor.is_available
                }
                for doctor in doctors
            ]
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error retrieving doctors: {str(e)}"
        )

# System Status Endpoints

@app.get("/system/status")
async def get_system_status(
    emergency_service: EmergencyPrioritizationService = Depends(get_emergency_service)
):
    """
    Get overall system status
    """
    try:
        status = emergency_service.get_system_status()
        return status
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error retrieving system status: {str(e)}"
        )

# Notification Endpoints

@app.post("/notifications/test")
async def send_test_notification(
    notification_service: NotificationService = Depends(get_notification_service)
):
    """
    Send a test notification
    """
    try:
        result = notification_service.send_system_alert(
            "test", "This is a test notification from HapiVet Emergency System", "low"
        )
        return {"success": result, "message": "Test notification sent"}
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error sending test notification: {str(e)}"
        )

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)

