from sqlalchemy import Column, Integer, String, DateTime, Boolean, Text, ForeignKey, Enum, Float
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime
import enum

Base = declarative_base()

class AppointmentStatus(str, enum.Enum):
    SCHEDULED = "scheduled"
    CONFIRMED = "confirmed"
    IN_PROGRESS = "in-progress"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    EMERGENCY = "emergency"

class AppointmentPriority(str, enum.Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    URGENT = "urgent"
    EMERGENCY = "emergency"

class SwapStatus(str, enum.Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"

class Patient(Base):
    __tablename__ = "patients"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    species = Column(String)
    breed = Column(String)
    age = Column(Integer)
    owner_name = Column(String)
    owner_phone = Column(String)
    owner_email = Column(String)
    preferred_doctor_id = Column(Integer, ForeignKey("doctors.id"))
    medical_history = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    appointments = relationship("Appointment", back_populates="patient")
    preferred_doctor = relationship("Doctor", foreign_keys=[preferred_doctor_id])

class Doctor(Base):
    __tablename__ = "doctors"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    specialization = Column(String)
    email = Column(String)
    phone = Column(String)
    is_available = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    appointments = relationship("Appointment", back_populates="doctor")
    shifts = relationship("DoctorShift", back_populates="doctor")

class Appointment(Base):
    __tablename__ = "appointments"
    
    id = Column(Integer, primary_key=True, index=True)
    patient_id = Column(Integer, ForeignKey("patients.id"))
    doctor_id = Column(Integer, ForeignKey("doctors.id"))
    scheduled_time = Column(DateTime, nullable=False)
    duration = Column(Integer, default=30)  # minutes
    status = Column(Enum(AppointmentStatus), default=AppointmentStatus.SCHEDULED)
    priority = Column(Enum(AppointmentPriority), default=AppointmentPriority.MEDIUM)
    reason = Column(Text)
    notes = Column(Text)
    is_emergency = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    patient = relationship("Patient", back_populates="appointments")
    doctor = relationship("Doctor", back_populates="appointments")
    swaps = relationship("AppointmentSwap", back_populates="original_appointment")

class DoctorShift(Base):
    __tablename__ = "doctor_shifts"
    
    id = Column(Integer, primary_key=True, index=True)
    doctor_id = Column(Integer, ForeignKey("doctors.id"))
    start_time = Column(DateTime, nullable=False)
    end_time = Column(DateTime, nullable=False)
    is_available = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    doctor = relationship("Doctor", back_populates="shifts")

class AppointmentSwap(Base):
    __tablename__ = "appointment_swaps"
    
    id = Column(Integer, primary_key=True, index=True)
    original_appointment_id = Column(Integer, ForeignKey("appointments.id"))
    new_appointment_id = Column(Integer, ForeignKey("appointments.id"))
    reason = Column(Text)
    status = Column(Enum(SwapStatus), default=SwapStatus.PENDING)
    requested_by = Column(String)  # User who requested the swap
    approved_by = Column(String)    # Admin who approved/rejected
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    original_appointment = relationship("Appointment", foreign_keys=[original_appointment_id])
    new_appointment = relationship("Appointment", foreign_keys=[new_appointment_id])

class EmergencyCase(Base):
    __tablename__ = "emergency_cases"
    
    id = Column(Integer, primary_key=True, index=True)
    patient_id = Column(Integer, ForeignKey("patients.id"))
    description = Column(Text, nullable=False)
    severity_score = Column(Integer, default=1)  # 1-10 scale
    ai_confidence = Column(Float, default=0.0)  # AI confidence in emergency classification
    assigned_doctor_id = Column(Integer, ForeignKey("doctors.id"))
    appointment_id = Column(Integer, ForeignKey("appointments.id"))
    status = Column(String, default="pending")  # pending, assigned, completed
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    patient = relationship("Patient")
    assigned_doctor = relationship("Doctor")
    appointment = relationship("Appointment")
