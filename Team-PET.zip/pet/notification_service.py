import smtplib
import requests
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Dict, List, Optional
from datetime import datetime
import config

class NotificationService:
    def __init__(self):
        self.admin_email = config.settings.admin_email
        self.webhook_url = config.settings.notification_webhook
        
    def send_emergency_notification(self, 
                                  emergency_case: Dict,
                                  assigned_doctor: Dict,
                                  appointment_details: Dict) -> bool:
        """Send emergency notification to relevant parties"""
        try:
            # Notify admin
            self._notify_admin_emergency(emergency_case, assigned_doctor, appointment_details)
            
            # Notify assigned doctor
            self._notify_doctor_emergency(assigned_doctor, emergency_case, appointment_details)
            
            # Send webhook notification if configured
            if self.webhook_url:
                self._send_webhook_notification("emergency", {
                    "case": emergency_case,
                    "doctor": assigned_doctor,
                    "appointment": appointment_details
                })
            
            return True
            
        except Exception as e:
            print(f"Error sending emergency notification: {e}")
            return False
    
    def send_swap_request_notification(self, swap_request: Dict) -> bool:
        """Send notification about swap request to admin"""
        try:
            subject = "Emergency Appointment Swap Request - Action Required"
            
            message = f"""
            Emergency Appointment Swap Request
            
            Original Appointment:
            - Patient: {swap_request['original_appointment']['patient_name']}
            - Time: {swap_request['original_appointment']['scheduled_time']}
            - Reason: {swap_request['original_appointment']['reason']}
            
            Emergency Appointment:
            - Patient: {swap_request['emergency_appointment']['patient_name']}
            - Time: {swap_request['emergency_appointment']['scheduled_time']}
            - Reason: {swap_request['emergency_appointment']['reason']}
            
            Requested by: {swap_request['requested_by']}
            Created at: {swap_request['created_at']}
            
            Please review and approve/reject this swap request.
            """
            
            # Send email to admin
            self._send_email(self.admin_email, subject, message)
            
            # Send webhook notification
            if self.webhook_url:
                self._send_webhook_notification("swap_request", swap_request)
            
            return True
            
        except Exception as e:
            print(f"Error sending swap request notification: {e}")
            return False
    
    def send_swap_approval_notification(self, 
                                      swap_request: Dict,
                                      approved: bool,
                                      admin_name: str) -> bool:
        """Send notification about swap approval/rejection"""
        try:
            status = "APPROVED" if approved else "REJECTED"
            subject = f"Emergency Swap Request {status}"
            
            message = f"""
            Your emergency swap request has been {status.lower()}.
            
            Original Appointment:
            - Patient: {swap_request['original_appointment']['patient_name']}
            - New Time: {swap_request['original_appointment']['scheduled_time']}
            
            Emergency Appointment:
            - Patient: {swap_request['emergency_appointment']['patient_name']}
            - Time: {swap_request['emergency_appointment']['scheduled_time']}
            
            {status} by: {admin_name}
            """
            
            # Send email to relevant parties
            self._send_email(self.admin_email, subject, message)
            
            # Send webhook notification
            if self.webhook_url:
                self._send_webhook_notification("swap_approval", {
                    "swap_request": swap_request,
                    "approved": approved,
                    "admin": admin_name
                })
            
            return True
            
        except Exception as e:
            print(f"Error sending swap approval notification: {e}")
            return False
    
    def send_appointment_reminder(self, 
                                appointment: Dict,
                                patient: Dict,
                                doctor: Dict) -> bool:
        """Send appointment reminder"""
        try:
            subject = "Appointment Reminder - HapiVet"
            
            message = f"""
            Appointment Reminder
            
            Patient: {patient['name']}
            Doctor: {doctor['name']}
            Time: {appointment['scheduled_time']}
            Reason: {appointment['reason']}
            
            Please arrive 10 minutes early for your appointment.
            """
            
            # Send email to patient
            if patient.get('owner_email'):
                self._send_email(patient['owner_email'], subject, message)
            
            return True
            
        except Exception as e:
            print(f"Error sending appointment reminder: {e}")
            return False
    
    def _notify_admin_emergency(self, 
                              emergency_case: Dict,
                              assigned_doctor: Dict,
                              appointment_details: Dict) -> None:
        """Notify admin about emergency case"""
        subject = "URGENT: Emergency Case Assigned"
        
        message = f"""
        EMERGENCY CASE ALERT
        
        Patient: {emergency_case.get('patient_name', 'Unknown')}
        Description: {emergency_case.get('description', '')}
        Severity Score: {emergency_case.get('severity_score', 0)}
        
        Assigned Doctor: {assigned_doctor.get('name', 'Unknown')}
        Appointment Time: {appointment_details.get('scheduled_time', 'Immediate')}
        
        This is an automated notification from the HapiVet Emergency System.
        """
        
        self._send_email(self.admin_email, subject, message)
    
    def _notify_doctor_emergency(self, 
                                doctor: Dict,
                                emergency_case: Dict,
                                appointment_details: Dict) -> None:
        """Notify doctor about emergency assignment"""
        subject = "URGENT: Emergency Case Assigned to You"
        
        message = f"""
        EMERGENCY CASE ASSIGNMENT
        
        Patient: {emergency_case.get('patient_name', 'Unknown')}
        Description: {emergency_case.get('description', '')}
        Severity Score: {emergency_case.get('severity_score', 0)}
        
        Appointment Time: {appointment_details.get('scheduled_time', 'Immediate')}
        
        Please prepare for immediate emergency consultation.
        """
        
        if doctor.get('email'):
            self._send_email(doctor['email'], subject, message)
    
    def _send_email(self, to_email: str, subject: str, message: str) -> bool:
        """Send email notification"""
        try:
            # This is a simplified email sending function
            # In production, you would use proper SMTP configuration
            print(f"EMAIL NOTIFICATION:")
            print(f"To: {to_email}")
            print(f"Subject: {subject}")
            print(f"Message: {message}")
            print("-" * 50)
            
            # Uncomment and configure for actual email sending:
            # msg = MIMEMultipart()
            # msg['From'] = "noreply@hapivet.com"
            # msg['To'] = to_email
            # msg['Subject'] = subject
            # msg.attach(MIMEText(message, 'plain'))
            # 
            # server = smtplib.SMTP('smtp.gmail.com', 587)
            # server.starttls()
            # server.login("your_email@gmail.com", "your_password")
            # server.send_message(msg)
            # server.quit()
            
            return True
            
        except Exception as e:
            print(f"Error sending email: {e}")
            return False
    
    def _send_webhook_notification(self, event_type: str, data: Dict) -> bool:
        """Send webhook notification"""
        try:
            if not self.webhook_url:
                return True
            
            payload = {
                "event_type": event_type,
                "timestamp": datetime.now().isoformat(),
                "data": data
            }
            
            response = requests.post(self.webhook_url, json=payload, timeout=10)
            response.raise_for_status()
            
            return True
            
        except Exception as e:
            print(f"Error sending webhook notification: {e}")
            return False
    
    def send_system_alert(self, alert_type: str, message: str, severity: str = "medium") -> bool:
        """Send system alert to admin"""
        try:
            subject = f"HapiVet System Alert - {alert_type.upper()}"
            
            alert_message = f"""
            System Alert: {alert_type}
            Severity: {severity.upper()}
            Time: {datetime.now()}
            
            Message: {message}
            
            This is an automated system alert from HapiVet.
            """
            
            self._send_email(self.admin_email, subject, alert_message)
            
            return True
            
        except Exception as e:
            print(f"Error sending system alert: {e}")
            return False

